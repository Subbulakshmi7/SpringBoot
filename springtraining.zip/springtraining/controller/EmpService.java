package com.gavs.springtraining.controller;

import java.sql.SQLException;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.gavs.springtraining.model.Employee;
import com.gavs.springtraining.model.EmployeeDAO;

@RestController
public class EmpService {
	
	@RequestMapping("/hello")
    public String welcomepage() {
        return "hello to Spring REST Controller";
    }
	
    @RequestMapping(value="/findEmployee",method= RequestMethod.POST)
    public Employee findEmployee(@RequestBody Employee emp)  {
    	EmployeeDAO dao=new EmployeeDAO();
    		System.out.println(emp.getEmpid());
			
			
		return dao.find(emp.getEmpid());
    }
    @RequestMapping(value="/addEmployee",method= RequestMethod.POST)
    
    public int addEmployee() {
    	EmployeeDAO dao=new EmployeeDAO();
    	System.out.println();
        return 0;
    }
    @RequestMapping(value="/updateEmployee",method= RequestMethod.PUT)
    public int modifyEmployee() {
        return 0;
    }
    @RequestMapping(value="/removeEmployee",method= RequestMethod.DELETE)
    public Employee removeEmployee(@RequestBody Employee e) {
    	EmployeeDAO eobj = new EmployeeDAO();
        eobj.delete(e.getEmpid());
        System.out.println("1 record Deleted successfully..!");
        return e;
     
        
    }
}
