package com.gavs.springtraining.model;

public class Employee {
	private int Empid;
	private String EmpName;
	private String EmpEmail;
	private long EmpMobileNumber;
	public int getEmpid() {
		return Empid;
	}
	public void setEmpid(int empid) {
		Empid = empid;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public String getEmpEmail() {
		return EmpEmail;
	}
	public void setEmpEmail(String empEmail) {
		EmpEmail = empEmail;
	}
	public long getEmpMobileNumber() {
		return EmpMobileNumber;
	}
	public void setEmpMobileNumber(long empMobileNumber) {
		EmpMobileNumber = empMobileNumber;
	}
	
	
	
	
}
