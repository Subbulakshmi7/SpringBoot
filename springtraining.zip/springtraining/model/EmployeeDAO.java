package com.gavs.springtraining.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EmployeeDAO {

	private static String MYSQL_DRIVERNAME="com.mysql.cj.jdbc.Driver";
    private static String MYSQL_CONNECTION_URL="jdbc:mysql://localhost:3306/infodb";
    static Connection con =null;
    Statement stmt;
    ResultSet rs=null;
    PreparedStatement ps;
    
    Employee app=new Employee();
    public  static Connection GetConnection()
    {
   
    String strUserName="root";
    String strPassword="admin";  
    try
    {
        java.util.Properties p = new java.util.Properties();
        p.put("user",strUserName);
        p.put("password",strPassword);
        String driverName=MYSQL_DRIVERNAME;
        Class.forName(driverName);
        String url=MYSQL_CONNECTION_URL;
        con= DriverManager.getConnection(url,p);
        return con;
        
    }
     catch (SQLException sqe)
     {
    	 sqe.printStackTrace();
       return null;
     }catch (Exception e2)
     {
    	 e2.printStackTrace();
        return null;
     }
    }
    public int insert(Employee employee) throws SQLException
    {
    	
    	
		try {
			ps = GetConnection().prepareStatement("insert into EmployeeDetail (empid,empname,num,email) values (?,?,?,?)");
			ps.setInt(1,employee.getEmpid());
			ps.setString(1,employee.getEmpName());
	        ps.setLong(2,employee.getEmpMobileNumber());
	        ps.setString(3,employee.getEmpEmail());
	        
	        int rs=ps.executeUpdate();
	        return rs;
	      
		} catch (SQLException e) {
			e.printStackTrace();
		}
		 GetConnection().close();
		return 0;
		
    }
    public Employee find(int id) 
    
    {
    	int a=id;
    	Employee emp = new Employee();
    	try { 
    		ps=GetConnection().prepareStatement("select empid,empname,num,email from EmployeeDetail where empid=?");
    		ps.setInt(1,a);
			rs=ps.executeQuery();
			
		while(rs.next()){
				emp.setEmpid(rs.getInt(1));
				emp.setEmpName(rs.getString(2));
				emp.setEmpMobileNumber(rs.getLong(3));
				emp.setEmpEmail(rs.getString(4));
				System.out.println(rs.getInt(1)+" "+rs.getString(2));
		} return emp;
		}
    	catch(SQLException ee)
    	{
    		ee.printStackTrace();
    		return null;
    	}
    		catch (Exception e) {
    			e.printStackTrace();
    			return null;
				
		}
    	finally {
			try {
				GetConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}
    	
    }

    public Employee delete(int id) 
    {
    	Employee emp=new Employee();
    	
    	try {
    		ps=GetConnection().prepareStatement("delete from EmployeeDetail where empid = ?");
    		ps.setInt(1, id);
			ps.executeUpdate();
	       
		}catch(SQLException e1)
    	{
			e1.printStackTrace();
    	}
    	catch (Exception e) {
		e.printStackTrace();
		}
    	finally {
			try {
				GetConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}
    	return emp;
    }
    public Employee update(int id,String name,String num,String email)
    {
    	try {
    		ps=GetConnection().prepareStatement("update EmployeeDetail set empid=?,empname=?,num=?,email=? where empid=?");
    		ps.setInt(1, id);
    		ps.setString(2,name);
    		ps.setString(3, num);
			ps.setString(4,email);
			
			ps.executeUpdate();
		        //return rs;
			
    } catch (Exception e) {
		e.printStackTrace();
		}
    	finally {
			try {
				GetConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}
		return null;
    	
    }
}
